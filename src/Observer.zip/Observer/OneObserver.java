package Observer;

public class OneObserver extends Observer{

	@Override
	public void update() {
		System.out.println("观察者1的age为12");
	}

}
